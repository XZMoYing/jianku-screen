#include <VideoToolbox/VideoToolbox.h>
#include <CoreMedia/CoreMedia.h>
#include <dlfcn.h>
#include <stdio.h>
static int session_number=0;
static int frame_number=0;
struct ProbeState { VTDecompressionOutputCallbackRecord original; int session; int frame; };
static void probe_callback(void *opaque, void *ref, OSStatus status, VTDecodeInfoFlags flags, CVImageBufferRef image, CMTime pts, CMTime duration) {
    struct ProbeState *state=opaque;
    if(image && status==noErr){
        CVPixelBufferLockBaseAddress(image,kCVPixelBufferLock_ReadOnly);
        for(int plane=0;plane<2;plane++){
            char path[2048];snprintf(path,sizeof(path),"/private/tmp/jianku-alpha38-parity/callback-%d-%d-%d.bin",state->session,state->frame,plane);
            FILE *file=fopen(path,"wb");size_t width=CVPixelBufferGetWidth(image),height=CVPixelBufferGetHeightOfPlane(image,plane),stride=CVPixelBufferGetBytesPerRowOfPlane(image,plane);
            const unsigned char *base=CVPixelBufferGetBaseAddressOfPlane(image,plane);
            for(size_t row=0;row<height;row++)fwrite(base+row*stride,1,width,file);
            fclose(file);
        }
        CVPixelBufferUnlockBaseAddress(image,kCVPixelBufferLock_ReadOnly);
        state->frame++;
    }
    state->original.decompressionOutputCallback(state->original.decompressionOutputRefCon,ref,status,flags,image,pts,duration);
}
static OSStatus probe_create(CFAllocatorRef a, CMVideoFormatDescriptionRef f, CFDictionaryRef d, CFDictionaryRef b, const VTDecompressionOutputCallbackRecord *c, VTDecompressionSessionRef *s) {
    char path[2048];snprintf(path,sizeof(path),"/private/tmp/jianku-alpha38-parity/ffmpeg-session-%d.plist",session_number++);
    frame_number=0;
    char full_path[2048];snprintf(full_path,sizeof(full_path),"/private/tmp/jianku-alpha38-parity/ffmpeg-session-%d-full.plist",session_number-1);
    CFStringRef keys[]={CFSTR("extensions"),CFSTR("decoderSpec"),CFSTR("bufferAttrs")};
    CFTypeRef values[]={CMFormatDescriptionGetExtensions(f),d,b};
    CFDictionaryRef dictionary=CFDictionaryCreate(NULL,(const void**)keys,(const void**)values,3,&kCFTypeDictionaryKeyCallBacks,&kCFTypeDictionaryValueCallBacks);
    CFDataRef full=CFPropertyListCreateData(NULL,dictionary,kCFPropertyListXMLFormat_v1_0,0,NULL);
    FILE *full_file=fopen(full_path,"wb");fwrite(CFDataGetBytePtr(full),1,CFDataGetLength(full),full_file);fclose(full_file);CFRelease(full);CFRelease(dictionary);
    CFDictionaryRef extensions=CMFormatDescriptionGetExtensions(f);
    CFDataRef data=CFPropertyListCreateData(NULL,extensions,kCFPropertyListXMLFormat_v1_0,0,NULL);
    if(data){FILE *file=fopen(path,"wb");fwrite(CFDataGetBytePtr(data),1,CFDataGetLength(data),file);fclose(file);CFRelease(data);}
    struct ProbeState *state=malloc(sizeof(*state));state->original=*c;state->session=session_number-1;state->frame=0;
    VTDecompressionOutputCallbackRecord callback={probe_callback,state};
    return VTDecompressionSessionCreate(a,f,d,b,&callback,s);
}
static OSStatus probe_decode(VTDecompressionSessionRef session, CMSampleBufferRef sample, VTDecodeFrameFlags flags, void *ref, VTDecodeInfoFlags *info) {
    CMBlockBufferRef buffer=CMSampleBufferGetDataBuffer(sample);
    size_t length=CMBlockBufferGetDataLength(buffer);
    unsigned char *data=malloc(length);
    CMBlockBufferCopyDataBytes(buffer,0,length,data);
    char path[2048];snprintf(path,sizeof(path),"/private/tmp/jianku-alpha38-parity/ffmpeg-packet-%d-%d.bin",session_number-1,frame_number++);
    FILE *file=fopen(path,"wb");fwrite(data,1,length,file);fclose(file);free(data);
    return VTDecompressionSessionDecodeFrame(session,sample,flags,ref,info);
}
__attribute__((used)) static struct { const void *replacement; const void *replacee; } mappings[] __attribute__((section("__DATA,__interpose"))) = {{(const void *)probe_create,(const void *)VTDecompressionSessionCreate},{(const void *)probe_decode,(const void *)VTDecompressionSessionDecodeFrame}};
