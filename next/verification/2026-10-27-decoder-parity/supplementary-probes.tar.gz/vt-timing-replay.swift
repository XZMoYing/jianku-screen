import Foundation
import AVFoundation
import VideoToolbox
import CoreVideo

final class Sink {
    let directory: URL
    var index = 0
    init(_ directory: URL) throws {
        self.directory = directory
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    }
    func receive(_ image: CVImageBuffer, pts: CMTime) {
        CVPixelBufferLockBaseAddress(image, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(image, .readOnly) }
        let width = CVPixelBufferGetWidth(image)
        for plane in 0..<2 {
            let stride = CVPixelBufferGetBytesPerRowOfPlane(image, plane)
            let height = CVPixelBufferGetHeightOfPlane(image, plane)
            let base = CVPixelBufferGetBaseAddressOfPlane(image, plane)!
            var data = Data()
            for row in 0..<height { data.append(base.advanced(by: row * stride).assumingMemoryBound(to: UInt8.self), count: width) }
            try! data.write(to: directory.appendingPathComponent("\(index)-\(plane).bin"))
        }
        index += 1
    }
}

@main
struct Probe {
    static func main() async throws {
        let root = URL(fileURLWithPath: "/private/tmp/jianku-alpha38-parity")
        for name in ["display", "camera"] {
            for variant in ["replay"] {
                let asset = AVURLAsset(url: root.appendingPathComponent("media/\(name).mp4"))
                let track = try await asset.loadTracks(withMediaType: .video)[0]
                let reader = try AVAssetReader(asset: asset)
                let output = AVAssetReaderTrackOutput(track: track, outputSettings: nil)
                reader.add(output)
                reader.startReading()
                let sink = try Sink(root.appendingPathComponent("vt-\(variant)-\(name)"))
                var callback = VTDecompressionOutputCallbackRecord(decompressionOutputCallback: { ref, _, status, _, image, pts, _ in
                    guard status == noErr, let image, let ref else { fatalError("Decode error \(status)") }
                    Unmanaged<Sink>.fromOpaque(ref).takeUnretainedValue().receive(image, pts: pts)
                }, decompressionOutputRefCon: Unmanaged.passUnretained(sink).toOpaque())
                var session: VTDecompressionSession?
                var count = 0
                var replacementDescription: CMVideoFormatDescription?
                while let sample = output.copyNextSampleBuffer(), count < 110 {
                    guard CMSampleBufferGetNumSamples(sample) > 0, let description = CMSampleBufferGetFormatDescription(sample) else { continue }
                    if session == nil {
                        var specification: [String: Any]
                        if variant == "hardware" { specification = [kVTVideoDecoderSpecification_RequireHardwareAcceleratedVideoDecoder as String: true] }
                        else if variant == "software" { specification = [kVTVideoDecoderSpecification_EnableHardwareAcceleratedVideoDecoder as String: false] }
                        else { specification = [:] }
                        let dimensions = CMVideoFormatDescriptionGetDimensions(description)
                        var attrs: [String: Any] = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange]
                        if variant != "description" {
                            attrs[kCVPixelBufferWidthKey as String] = dimensions.width
                            attrs[kCVPixelBufferHeightKey as String] = dimensions.height
                            attrs[kCVPixelBufferIOSurfacePropertiesKey as String] = [:]
                            attrs[kCVPixelBufferIOSurfaceOpenGLTextureCompatibilityKey as String] = true
                        }
                        if variant != "attrs" {
                            let atoms = CMFormatDescriptionGetExtension(description, extensionKey: kCMFormatDescriptionExtension_SampleDescriptionExtensionAtoms)!
                            let extensions: [String: Any] = [kCMFormatDescriptionExtension_SampleDescriptionExtensionAtoms as String: atoms, kVTVideoDecoderSpecification_RequireHardwareAcceleratedVideoDecoder as String: true]
                            let formatStatus = CMVideoFormatDescriptionCreate(allocator: nil, codecType: kCMVideoCodecType_H264, width: dimensions.width, height: dimensions.height, extensions: extensions as CFDictionary, formatDescriptionOut: &replacementDescription)
                            precondition(formatStatus == noErr)
                        }
                        let settings = try PropertyListSerialization.propertyList(from: Data(contentsOf: root.appendingPathComponent(name == "display" ? "ffmpeg-session-0-full.plist" : "ffmpeg-session-2-full.plist")), format: nil) as! [String: Any]
                        attrs = settings["bufferAttrs"] as! [String: Any]
                        specification = settings["decoderSpec"] as! [String: Any]
                        let setStatus = CMVideoFormatDescriptionCreate(allocator: nil, codecType: kCMVideoCodecType_H264, width: dimensions.width, height: dimensions.height, extensions: settings["extensions"] as! CFDictionary, formatDescriptionOut: &replacementDescription)
                        precondition(setStatus == noErr)
                        let status = VTDecompressionSessionCreate(allocator: nil, formatDescription: replacementDescription ?? description, decoderSpecification: specification as CFDictionary, imageBufferAttributes: attrs as CFDictionary, outputCallback: &callback, decompressionSessionOut: &session)
                        guard status == noErr, let session else { print(name,variant,"create failed",status); break }
                        var value: UnsafeRawPointer?
                        VTSessionCopyProperty(session, key: kVTDecompressionPropertyKey_UsingHardwareAcceleratedVideoDecoder, allocator: nil, valueOut: &value)
                        print(name, variant, "usingHardware", value.map { Unmanaged<CFBoolean>.fromOpaque($0).takeRetainedValue() } as Any)
                    }
                    var decodeSample = sample
                    if let replacementDescription {
                        var updated: CMSampleBuffer?
                        var timing = CMSampleTimingInfo(duration: CMSampleBufferGetDuration(sample), presentationTimeStamp: CMSampleBufferGetPresentationTimeStamp(sample), decodeTimeStamp: CMSampleBufferGetDecodeTimeStamp(sample))
                        var size = CMSampleBufferGetTotalSampleSize(sample)
                        let createStatus = withUnsafePointer(to: &timing) { timingPointer in
                            withUnsafePointer(to: &size) { sizePointer in
                                CMSampleBufferCreateReady(allocator: nil, dataBuffer: CMSampleBufferGetDataBuffer(sample), formatDescription: replacementDescription, sampleCount: 1, sampleTimingEntryCount: variant == "unsized" ? 1 : 0, sampleTimingArray: variant == "unsized" ? timingPointer : nil, sampleSizeEntryCount: variant == "untimed" ? 1 : 0, sampleSizeArray: variant == "untimed" ? sizePointer : nil, sampleBufferOut: &updated)
                            }
                        }
                        precondition(createStatus == noErr)
                        decodeSample = updated!
                    }
                    let status = VTDecompressionSessionDecodeFrame(session!, sampleBuffer: decodeSample, flags: [], frameRefcon: nil, infoFlagsOut: nil)
                    guard status == noErr else { fatalError("Decode \(status)") }
                    VTDecompressionSessionWaitForAsynchronousFrames(session!)
                    count += 1
                }
                if let session {
                    VTDecompressionSessionFinishDelayedFrames(session)
                    VTDecompressionSessionWaitForAsynchronousFrames(session)
                    VTDecompressionSessionInvalidate(session)
                }
                reader.cancelReading()
                print(name, variant, "frames", sink.index)
            }
        }
    }
}
