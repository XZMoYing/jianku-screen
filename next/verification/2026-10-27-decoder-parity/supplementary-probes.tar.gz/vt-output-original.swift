import Foundation
import AVFoundation
import VideoToolbox
import CoreVideo

final class Sink {
    let directory: URL
    var index = 0
    init(_ directory: URL) throws {
        self.directory = directory
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    }
    func receive(_ image: CVImageBuffer, pts: CMTime) {
        CVPixelBufferLockBaseAddress(image, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(image, .readOnly) }
        let width = CVPixelBufferGetWidth(image)
        for plane in 0..<2 {
            let stride = CVPixelBufferGetBytesPerRowOfPlane(image, plane)
            let height = CVPixelBufferGetHeightOfPlane(image, plane)
            let base = CVPixelBufferGetBaseAddressOfPlane(image, plane)!
            var data = Data()
            for row in 0..<height { data.append(base.advanced(by: row * stride).assumingMemoryBound(to: UInt8.self), count: width) }
            try! data.write(to: directory.appendingPathComponent("\(index)-\(plane).bin"))
        }
        index += 1
    }
}

@main
struct Probe {
    static func main() async throws {
        let root = URL(fileURLWithPath: "/private/tmp/jianku-alpha38-parity")
        for name in ["display", "camera"] {
            for variant in ["default", "software", "hardware"] {
                let asset = AVURLAsset(url: root.appendingPathComponent("media/\(name).mp4"))
                let track = try await asset.loadTracks(withMediaType: .video)[0]
                let reader = try AVAssetReader(asset: asset)
                let output = AVAssetReaderTrackOutput(track: track, outputSettings: nil)
                reader.add(output)
                reader.startReading()
                let sink = try Sink(root.appendingPathComponent("vt-\(variant)-\(name)"))
                var callback = VTDecompressionOutputCallbackRecord(decompressionOutputCallback: { ref, _, status, _, image, pts, _ in
                    guard status == noErr, let image, let ref else { fatalError("Decode error \(status)") }
                    Unmanaged<Sink>.fromOpaque(ref).takeUnretainedValue().receive(image, pts: pts)
                }, decompressionOutputRefCon: Unmanaged.passUnretained(sink).toOpaque())
                var session: VTDecompressionSession?
                var count = 0
                while let sample = output.copyNextSampleBuffer(), count < 110 {
                    guard CMSampleBufferGetNumSamples(sample) > 0, let description = CMSampleBufferGetFormatDescription(sample) else { continue }
                    if session == nil {
                        let specification: [String: Any]
                        if variant == "hardware" { specification = [kVTVideoDecoderSpecification_RequireHardwareAcceleratedVideoDecoder as String: true] }
                        else if variant == "software" { specification = [kVTVideoDecoderSpecification_EnableHardwareAcceleratedVideoDecoder as String: false] }
                        else { specification = [:] }
                        let attrs: [String: Any] = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange]
                        let status = VTDecompressionSessionCreate(allocator: nil, formatDescription: description, decoderSpecification: specification as CFDictionary, imageBufferAttributes: attrs as CFDictionary, outputCallback: &callback, decompressionSessionOut: &session)
                        guard status == noErr, let session else { print(name,variant,"create failed",status); break }
                        var value: UnsafeRawPointer?
                        VTSessionCopyProperty(session, key: kVTDecompressionPropertyKey_UsingHardwareAcceleratedVideoDecoder, allocator: nil, valueOut: &value)
                        print(name, variant, "usingHardware", value.map { Unmanaged<CFBoolean>.fromOpaque($0).takeRetainedValue() } as Any)
                    }
                    let status = VTDecompressionSessionDecodeFrame(session!, sampleBuffer: sample, flags: [], frameRefcon: nil, infoFlagsOut: nil)
                    guard status == noErr else { fatalError("Decode \(status)") }
                    count += 1
                }
                if let session {
                    VTDecompressionSessionFinishDelayedFrames(session)
                    VTDecompressionSessionWaitForAsynchronousFrames(session)
                    VTDecompressionSessionInvalidate(session)
                }
                reader.cancelReading()
                print(name, variant, "frames", sink.index)
            }
        }
    }
}
