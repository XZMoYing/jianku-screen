#include <VideoToolbox/VideoToolbox.h>
#include <CoreFoundation/CoreFoundation.h>
#include <stdio.h>
static int count=0;
static void dump(CFTypeRef value,const char *prefix) {
    char path[2048];snprintf(path,sizeof(path),"/private/tmp/jianku-decode-stability/%s-%d.plist",prefix,count++);
    if(!value)return;
    CFDataRef data=CFPropertyListCreateData(NULL,value,kCFPropertyListXMLFormat_v1_0,0,NULL);
    if(!data)return;
    FILE *file=fopen(path,"wb");fwrite(CFDataGetBytePtr(data),1,CFDataGetLength(data),file);fclose(file);CFRelease(data);
}
static OSStatus set_property(VTSessionRef s,CFStringRef k,CFTypeRef v) {
    const void *keys[]={CFSTR("key"),CFSTR("value")};const void *values[]={k,v?v:kCFNull};
    CFDictionaryRef d=CFDictionaryCreate(NULL,keys,values,2,&kCFTypeDictionaryKeyCallBacks,&kCFTypeDictionaryValueCallBacks);dump(d,"set-property");CFRelease(d);
    return VTSessionSetProperty(s,k,v);
}
static OSStatus create_session(CFAllocatorRef a,CMVideoFormatDescriptionRef f,CFDictionaryRef d,CFDictionaryRef b,const VTDecompressionOutputCallbackRecord *c,VTDecompressionSessionRef *s) {
    OSStatus status=VTDecompressionSessionCreate(a,f,d,b,c,s);
    if(status==noErr) {
        CFDictionaryRef props=NULL;
        VTSessionCopySupportedPropertyDictionary(*s,&props);dump(props,"supported");if(props)CFRelease(props);
        CFDictionaryRef current=NULL;
        VTSessionCopySerializableProperties(*s,NULL,&current);dump(current,"current");if(current)CFRelease(current);
    }
    return status;
}
__attribute__((used)) static struct { const void *replacement; const void *replacee; } mappings[] __attribute__((section("__DATA,__interpose"))) = {{(const void *)set_property,(const void *)VTSessionSetProperty},{(const void *)create_session,(const void *)VTDecompressionSessionCreate}};
