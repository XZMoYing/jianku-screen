#include <VideoToolbox/VideoToolbox.h>
#include <CoreMedia/CoreMedia.h>
#include <stdlib.h>
static OSStatus decode(VTDecompressionSessionRef session,CMSampleBufferRef sample,VTDecodeFrameFlags flags,void *ref,VTDecodeInfoFlags *info) {
    CMBlockBufferRef source=CMSampleBufferGetDataBuffer(sample),copy=NULL;
    size_t length=CMBlockBufferGetDataLength(source);
    unsigned char *bytes=malloc(length);
    if(CMBlockBufferCopyDataBytes(source,0,length,bytes)!=noErr)abort();
    if(CMBlockBufferCreateWithMemoryBlock(NULL,NULL,length,kCFAllocatorDefault,NULL,0,length,0,&copy)!=noErr)abort();
    if(CMBlockBufferReplaceDataBytes(bytes,copy,0,length)!=noErr)abort();
    free(bytes);
    CMSampleBufferRef updated=NULL;size_t size=length;
    if(CMSampleBufferCreateReady(NULL,copy,CMSampleBufferGetFormatDescription(sample),1,0,NULL,1,&size,&updated)!=noErr)abort();
    OSStatus result=VTDecompressionSessionDecodeFrame(session,updated,flags,ref,info);
    VTDecompressionSessionWaitForAsynchronousFrames(session);
    CFRelease(updated);CFRelease(copy);
    return result;
}
__attribute__((used)) static struct {const void *replacement;const void *replacee;} mappings[] __attribute__((section("__DATA,__interpose")))={{(const void*)decode,(const void*)VTDecompressionSessionDecodeFrame}};
